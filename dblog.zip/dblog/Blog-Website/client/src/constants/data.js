export const categories = [
    { id: 1, type: "Travel" },
    { id: 2, type: "Nature" },
    { id: 3, type: "Campus" },
    { id: 4, type: "Food" },
];
