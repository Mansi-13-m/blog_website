
import { AppBar, Toolbar, styled, Button } from '@mui/material'; 
import { fontGrid } from '@mui/material/styles/cssUtils';
import { Link } from 'react-router-dom';

import { useNavigate } from 'react-router-dom';


const Component = styled(AppBar)`
    background: #FFFFFF;
    color: black;
`;

const Container = styled(Toolbar)`
    justify-content: center;
    & > a {
        padding: 20px;
        color: #000;
        text-decoration: none;
    }
`




const Header = () => {

    const navigate = useNavigate();

    const logout = async () => navigate('/account');
        
    return (
        <Component>

            <Container>
            <img src={'https://th.bing.com/th/id/OIP.CxWG-028N4LQZjJED21DXwAAAA?pid=ImgDet&w=200&h=200&c=7&dpr=1.3'} width='90px' padding='20px' alt="blog" /> 

                <Link to='/'><h5><i>HOME</i></h5></Link>
                <Link to='/about'><h5><i>ABOUT</i></h5></Link>
                <Link to='/contact'><h5><i>CONTACT</i></h5></Link>
                <Link to='/account'><h5><i>LOGOUT</i></h5></Link>
            </Container>
        </Component>
    )
}

export default Header;