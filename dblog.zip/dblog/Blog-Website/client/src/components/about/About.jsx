
import { Box, styled, Typography, Link } from '@mui/material';
import { GitHub, Instagram, Email } from '@mui/icons-material';

const Banner = styled(Box)`
    background-image: url(https://images.unsplash.com/photo-1518481852452-9415b262eba4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGFib3V0fGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60);
    width: 100%;
    height: 70vh;
    background-position: left 0px bottom 0px;
    background-size: cover;
`;

const Wrapper = styled(Box)`
    padding: 20px;
    & > h3, & > h5 {
        margin-top: 50px;
    }
`;

const Text = styled(Typography)`
    color: #878787;
`;

const About = () => {

    return (
        <Box>
            <Banner/>
            <Wrapper>
                <Typography variant="h2"><i>About</i></Typography>
                <Text variant="h5">Our team is comprised of dedicated writers, editors, and contributors who are experts in their respective fields. We carefully curate each piece of content to ensure it is informative, well-researched, and engaging. Whether you're looking for practical tips, thought-provoking articles, or entertaining stories, we've got you covered.
                    
                </Text>
                <Text variant="h5">
                Thank you for visiting our blog. We hope that you find the content enjoyable, informative, and thought-provoking. Join us on this exciting journey as we continue to explore new horizons, challenge perspectives, and celebrate the beauty of knowledge and storytelling.

Happy reading!
                </Text>
            </Wrapper>
        </Box>
    )
}

export default About;