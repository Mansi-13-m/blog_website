
import { styled, Box, Typography } from '@mui/material';

const Image = styled(Box)`
    width: 100%;
    background: url(https://images.unsplash.com/photo-1421789665209-c9b2a435e3dc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=871&q=80) center/55% repeat-x #000;
    height: 70vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    repeat:no-repeat;
    
`;

const Heading = styled(Typography)`
    font-size: 50px;
    color: white;
    line-height: 1;

`;



const Banner = () => {
    
    return (
        <Image>
            <Heading color='black' ><i><h3>"Blogging is a conversation</h3></i></Heading>
            <Heading>not a code"</Heading>
        </Image>
    )
}

export default Banner;